@extends('avisos.layouts.base')


@section('content')

    <div style="width: 100%; text-align: left; background-color: #EFEFEF; float: left; font-family: Arial, Helvetica, sans-serif; color: #222; padding: 10px;">
        <h3 style="padding-bottom: 10px; float: left">Error en la web</h3>

        <p style="width: 100%; padding-bottom: 0px; float: left;">
            Se produjo un error en la web
        </p>
    </div>
@endsection

