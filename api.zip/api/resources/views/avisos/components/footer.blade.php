<div style="background-color:#a83636;width: 100%; text-align: center; padding: 10px; color: #EEE; box-sizing: border-box; float: left">
   <small>
       Este correo electrónico fue enviado desde una dirección exclusiva de notificaciones que no recibe correos electrónicos. No respondas a este mensaje. Si tienes una pregunta o inquietud, por favor contáctanos en nuestra web
   </small>
</div>
