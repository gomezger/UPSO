


<?php $__env->startSection('content'); ?>

    <div style="width: 100%; text-align: left; background-color: #EFEFEF; float: left; font-family: Arial, Helvetica, sans-serif; color: #222; padding: 10px; box-sizing: border-box">
        <h3 style="padding-bottom: 10px; float: left">Descargar publicación</h3>

        <p style="width: 100%; padding-bottom: 0px; float: left;">
            Estás recibiendo este correo electrónico porque recibimos una solicitud para descargar una publicación.
        </p>

        <p style="width: 100%; padding-bottom: 0px; float: left; text-align: center">
            <a
                style="background-color: #ba4545; padding: 10px; border-radius: 5px; color: #FEFEFE; margin: 7px 0; display: inline-block"
                href="<?php echo e(config('app.web_url')); ?>/publicaciones/download/<?php echo e($data['id']); ?>"
            >Descargar</a>
        </p>

        <p style="width: 100%; padding-bottom: 0px; float: left;">
            Si no solicitó descargar la publicación, no es necesario realizar ninguna otra acción.
        </p>

        <p style="width: 100%; padding-bottom: 0px; float: left;">
            <small>Si tiene problemas para hacer clic en el botón "Descargar", copie y pegue la siguiente URL en su navegador web: <a href="<?php echo e(config('app.web_url')); ?>/publicaciones/download/<?php echo e($data['id']); ?>"><?php echo e(config('app.web_url')); ?>/publicaciones/download/<?php echo e($data['id']); ?></a></small>
        </p>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('avisos.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\www\UPSO\api\resources\views/avisos/paper/download.blade.php ENDPATH**/ ?>