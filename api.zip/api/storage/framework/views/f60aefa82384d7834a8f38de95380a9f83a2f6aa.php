<div style="background-color:#a83636;width: 100%; text-align: center; padding: 20px; box-sizing: border-box">
    <img alt="Upso Investigación" title="Toyomec Repuestos" style="width: 300px; max-width: 98%"
        src="<?php echo e(config('app.web_url')); ?>/assets/img/logos/logo-UPSO.png" />
</div>
<?php /**PATH X:\www\UPSO\api\resources\views/avisos/components/header.blade.php ENDPATH**/ ?>